# String replacer

String replacer / expander.

See the JSON config in `content.json` for the strings.
