# Remove Amazon sponsored

Firefox Add-on to remove Amazon sponsored products from search results / listings.

